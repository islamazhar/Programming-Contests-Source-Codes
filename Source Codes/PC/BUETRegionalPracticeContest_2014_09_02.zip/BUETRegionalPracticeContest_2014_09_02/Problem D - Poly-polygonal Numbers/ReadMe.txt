Following configuration was used to run the solutions:

   Operating System: Windows 7 Home Premium 64-bit (6.1, Build 7601) Service Pack 1 (7601.win7sp1_gdr.130828-1532)
          Processor: Intel(R) Core(TM) i3 CPU       M 370  @ 2.40GHz (4 CPUs), ~2.4GHz
             Memory: 4096MB RAM


Judge solution completes in 0.3 seconds